﻿using System;
using System.Windows;
using System.Windows.Media.Animation;

namespace InventoryApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
           
        }

        private void VideoPlayer_MediaEnded(object sender, RoutedEventArgs e)
        {
           
            VideoPlayer.Position = TimeSpan.Zero;
            VideoPlayer.Play();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
            Storyboard fadeInStoryboard = (Storyboard)FindResource("FadeInStoryboard");
            fadeInStoryboard.Begin(this);

            
            VideoPlayer.Play();
        }


        private void AboutButton_Click(object sender, RoutedEventArgs e)
        {
          
            AboutPopup.IsOpen = true;
        }

        private void ClosePopup_Click(object sender, RoutedEventArgs e)
        {
            
            AboutPopup.IsOpen = false;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                Signupform signupForm = new Signupform();
                signupForm.ShowDialog();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening Signup Form: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                
                LoginForm loginForm = new LoginForm();
                loginForm.ShowDialog();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening Login Form: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
