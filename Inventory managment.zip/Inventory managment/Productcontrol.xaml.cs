﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace InventoryApp
{
    public partial class Productcontrol : UserControl
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";
        private int currentUserId;

        public Productcontrol(int userId)
        {
            InitializeComponent();
            LoadProducts();
            InitializePlaceholders();
            currentUserId = userId;
        }

        private void LogAudit(int userId, string action, string tableAffected, string description)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime, Description) VALUES (@UserID, @Action, @TableAffected, @ActionTime, @Description)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Action", action);
                        command.Parameters.AddWithValue("@TableAffected", tableAffected);
                        command.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", description);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void InitializePlaceholders()
        {
            ProductNameTextBox.Text = "Enter Product Name";
            SKUTextBox.Text = "Enter SKU";
            CategoryTextBox.Text = "Enter Category";
            QuantityTextBox.Text = "Enter Quantity";
            UnitPriceTextBox.Text = "Enter Unit Price";
            BarcodeTextBox.Text = "Enter Barcode";
        }

        private void LoadProducts()
        {
            var products = new List<ProductItem>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ProductID, Name, SKU, Category, Quantity, UnitPrice, Barcode, CreatedAt, UpdatedAt FROM Products";
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var product = new ProductItem
                            {
                                ProductID = Convert.ToInt32(reader["ProductID"]),
                                Name = reader["Name"].ToString(),
                                SKU = reader["SKU"].ToString(),
                                Category = reader["Category"].ToString(),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                UnitPrice = Convert.ToDecimal(reader["UnitPrice"]),
                                Barcode = reader["Barcode"].ToString(),
                                CreatedAt = Convert.ToDateTime(reader["CreatedAt"]),
                                UpdatedAt = Convert.ToDateTime(reader["UpdatedAt"])
                            };
                            products.Add(product);
                        }
                    }
                }

                ProductsDataGrid.ItemsSource = products;
                StatusTextBlock.Text = $"Loaded {products.Count} products.";
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Error loading products: {ex.Message}";
            }
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ProductNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(SKUTextBox.Text) ||
                !int.TryParse(QuantityTextBox.Text, out var quantity) ||
                !decimal.TryParse(UnitPriceTextBox.Text, out var unitPrice))
            {
                StatusTextBlock.Text = "Product Name, SKU, Quantity, and Unit Price are required.";
                return;
            }

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Products (Name, SKU, Category, Quantity, UnitPrice, Barcode, CreatedAt, UpdatedAt) VALUES (@Name, @SKU, @Category, @Quantity, @UnitPrice, @Barcode, @CreatedAt, @UpdatedAt)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", ProductNameTextBox.Text.Trim());
                        command.Parameters.AddWithValue("@SKU", SKUTextBox.Text.Trim());
                        command.Parameters.AddWithValue("@Category", CategoryTextBox.Text.Trim());
                        command.Parameters.AddWithValue("@Quantity", quantity);
                        command.Parameters.AddWithValue("@UnitPrice", unitPrice);
                        command.Parameters.AddWithValue("@Barcode", BarcodeTextBox.Text.Trim());
                        command.Parameters.AddWithValue("@CreatedAt", DateTime.Now);
                        command.Parameters.AddWithValue("@UpdatedAt", DateTime.Now);

                        command.ExecuteNonQuery();
                    }
                }

                LogAudit(currentUserId, "Add", "Products", $"Added Product: {ProductNameTextBox.Text}");
                StatusTextBlock.Text = "Product added successfully.";
                InitializePlaceholders();
                LoadProducts();
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Error adding product: {ex.Message}";
            }
        }

        private void UpdateProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsDataGrid.SelectedItem is ProductItem selectedProduct)
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE Products SET Name = @Name, SKU = @SKU, Category = @Category, Quantity = @Quantity, UnitPrice = @UnitPrice, Barcode = @Barcode, UpdatedAt = @UpdatedAt WHERE ProductID = @ProductID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ProductID", selectedProduct.ProductID);
                            command.Parameters.AddWithValue("@Name", ProductNameTextBox.Text.Trim());
                            command.Parameters.AddWithValue("@SKU", SKUTextBox.Text.Trim());
                            command.Parameters.AddWithValue("@Category", CategoryTextBox.Text.Trim());
                            command.Parameters.AddWithValue("@Quantity", int.Parse(QuantityTextBox.Text));
                            command.Parameters.AddWithValue("@UnitPrice", decimal.Parse(UnitPriceTextBox.Text));
                            command.Parameters.AddWithValue("@Barcode", BarcodeTextBox.Text.Trim());
                            command.Parameters.AddWithValue("@UpdatedAt", DateTime.Now);

                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Update", "Products", $"Updated Product: {selectedProduct.ProductID}");
                    StatusTextBlock.Text = "Product updated successfully.";
                    InitializePlaceholders();
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    StatusTextBlock.Text = $"Error updating product: {ex.Message}";
                }
            }
            else
            {
                StatusTextBlock.Text = "Select a product to update.";
            }
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsDataGrid.SelectedItem is ProductItem selectedProduct)
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Products WHERE ProductID = @ProductID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ProductID", selectedProduct.ProductID);
                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Delete", "Products", $"Deleted Product: {selectedProduct.ProductID}");
                    StatusTextBlock.Text = "Product deleted successfully.";
                    InitializePlaceholders();
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    StatusTextBlock.Text = $"Error deleting product: {ex.Message}";
                }
            }
            else
            {
                StatusTextBlock.Text = "Select a product to delete.";
            }
        }

        private void ProductsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ProductsDataGrid.SelectedItem is ProductItem selectedProduct)
            {
                ProductNameTextBox.Text = selectedProduct.Name;
                SKUTextBox.Text = selectedProduct.SKU;
                CategoryTextBox.Text = selectedProduct.Category;
                QuantityTextBox.Text = selectedProduct.Quantity.ToString();
                UnitPriceTextBox.Text = selectedProduct.UnitPrice.ToString("F2");
                BarcodeTextBox.Text = selectedProduct.Barcode;
            }
        }
    }

    public class ProductItem
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string SKU { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string Barcode { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
