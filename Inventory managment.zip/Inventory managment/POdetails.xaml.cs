﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace InventoryApp
{
    public partial class POdetails : UserControl
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";
        private int currentUserId;

        public POdetails(int userId)
        {
            InitializeComponent();
            LoadPurchaseOrderDetails();
            InitializePlaceholders();
            currentUserId = userId;
        }

        private void LogAudit(int userId, string action, string tableAffected, string description)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime, Description) VALUES (@UserID, @Action, @TableAffected, @ActionTime, @Description)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Action", action);
                        command.Parameters.AddWithValue("@TableAffected", tableAffected);
                        command.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", description);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void InitializePlaceholders()
        {
            QuantityTextBox.Text = "Enter Quantity";
            UnitPriceTextBox.Text = "Enter Unit Price";
        }

        private void LoadPurchaseOrderDetails()
        {
            var purchaseOrderDetails = new List<PurchaseOrderDetailItem>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT PODetailID, PurchaseOrderID, ProductID, Quantity, UnitPrice FROM PurchaseOrderDetails";
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var detail = new PurchaseOrderDetailItem
                            {
                                PODetailID = Convert.ToInt32(reader["PODetailID"]),
                                PurchaseOrderID = Convert.ToInt32(reader["PurchaseOrderID"]),
                                ProductID = Convert.ToInt32(reader["ProductID"]),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                UnitPrice = Convert.ToDecimal(reader["UnitPrice"]),
                            };
                            purchaseOrderDetails.Add(detail);
                        }
                    }
                }

                PurchaseOrderDetailsDataGrid.ItemsSource = purchaseOrderDetails;
                StatusTextBlock.Text = $"Loaded {purchaseOrderDetails.Count} purchase order details.";
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Error loading purchase order details: {ex.Message}";
            }
        }

        private void AddPurchaseOrderDetail_Click(object sender, RoutedEventArgs e)
        {
           
            if (!int.TryParse(QuantityTextBox.Text, out var quantity) ||
                !decimal.TryParse(UnitPriceTextBox.Text, out var unitPrice) ||
                string.IsNullOrWhiteSpace(PurchaseOrderIDTextBox.Text) ||
                string.IsNullOrWhiteSpace(ProductIDTextBox.Text))
            {
                StatusTextBlock.Text = "Purchase Order ID, Product ID, Quantity, and Unit Price are required.";
                return;
            }

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    
                    string orderStatusQuery = "SELECT Status FROM PurchaseOrders WHERE PurchaseOrderID = @PurchaseOrderID";
                    string orderStatus = null;

                    using (var statusCommand = new SqlCommand(orderStatusQuery, connection))
                    {
                        statusCommand.Parameters.AddWithValue("@PurchaseOrderID", PurchaseOrderIDTextBox.Text.Trim());
                        orderStatus = (string)statusCommand.ExecuteScalar();
                    }

                    if (orderStatus == null)
                    {
                        StatusTextBlock.Text = "Purchase Order not found.";
                        return;
                    }

                    if (orderStatus == "Cancelled")
                    {
                        StatusTextBlock.Text = "Cannot add details to a cancelled purchase order.";
                        return;
                    }

                    
                    string productQuery = "SELECT Quantity FROM Products WHERE ProductID = @ProductID";
                    int availableQuantity = 0;

                    using (var productCommand = new SqlCommand(productQuery, connection))
                    {
                        productCommand.Parameters.AddWithValue("@ProductID", ProductIDTextBox.Text.Trim());
                        var result = productCommand.ExecuteScalar();

                        if (result != null)
                        {
                            availableQuantity = Convert.ToInt32(result);
                        }
                        else
                        {
                            StatusTextBlock.Text = "Product not found.";
                            return;
                        }
                    }

                    if (quantity > availableQuantity)
                    {
                        StatusTextBlock.Text = "Insufficient quantity available for this product.";
                        return;
                    }

                    
                    string insertQuery = "INSERT INTO PurchaseOrderDetails (PurchaseOrderID, ProductID, Quantity, UnitPrice) VALUES (@PurchaseOrderID, @ProductID, @Quantity, @UnitPrice)";
                    using (var insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@PurchaseOrderID", PurchaseOrderIDTextBox.Text.Trim());
                        insertCommand.Parameters.AddWithValue("@ProductID", ProductIDTextBox.Text.Trim());
                        insertCommand.Parameters.AddWithValue("@Quantity", quantity);
                        insertCommand.Parameters.AddWithValue("@UnitPrice", unitPrice);

                        insertCommand.ExecuteNonQuery();
                    }

                    
                    string updateProductQuery = "UPDATE Products SET Quantity = Quantity - @Quantity WHERE ProductID = @ProductID";
                    using (var updateCommand = new SqlCommand(updateProductQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@Quantity", quantity);
                        updateCommand.Parameters.AddWithValue("@ProductID", ProductIDTextBox.Text.Trim());

                        updateCommand.ExecuteNonQuery();
                    }
                }

                LogAudit(currentUserId, "Add", "PurchaseOrderDetails", $"Added Purchase Order Detail for Product ID: {ProductIDTextBox.Text}");
                StatusTextBlock.Text = "Purchase order detail added successfully.";
                InitializePlaceholders();
                LoadPurchaseOrderDetails();
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Error adding purchase order detail: {ex.Message}";
            }
        }

        private void UpdatePurchaseOrderDetail_Click(object sender, RoutedEventArgs e)
        {
            if (PurchaseOrderDetailsDataGrid.SelectedItem is PurchaseOrderDetailItem selectedDetail)
            {
                if (!int.TryParse(QuantityTextBox.Text, out var newQuantity) ||
                    !decimal.TryParse(UnitPriceTextBox.Text, out var unitPrice))
                {
                    StatusTextBlock.Text = "Quantity and Unit Price are required.";
                    return;
                }

                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                       
                        int currentQuantity = selectedDetail.Quantity;

                       
                        string productQuery = "SELECT Quantity FROM Products WHERE ProductID = @ProductID";
                        int availableQuantity = 0;

                        using (var productCommand = new SqlCommand(productQuery, connection))
                        {
                            productCommand.Parameters.AddWithValue("@ProductID", selectedDetail.ProductID);
                            var result = productCommand.ExecuteScalar();

                            if (result != null)
                            {
                                availableQuantity = Convert.ToInt32(result);
                            }
                            else
                            {
                                StatusTextBlock.Text = "Product not found.";
                                return;
                            }
                        }

                       
                        int quantityDifference = newQuantity - currentQuantity;

                       
                        if (quantityDifference > 0 && quantityDifference > availableQuantity)
                        {
                            StatusTextBlock.Text = "Insufficient quantity available for this product.";
                            return;
                        }

                       
                        string updateQuery = "UPDATE PurchaseOrderDetails SET Quantity = @Quantity, UnitPrice = @UnitPrice WHERE PODetailID = @PODetailID";
                        using (var updateCommand = new SqlCommand(updateQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@PODetailID", selectedDetail.PODetailID);
                            updateCommand.Parameters.AddWithValue("@Quantity", newQuantity);
                            updateCommand.Parameters.AddWithValue("@UnitPrice", unitPrice);
                            updateCommand.ExecuteNonQuery();
                        }

                        
                        string updateProductQuery = "UPDATE Products SET Quantity = Quantity - @QuantityDifference WHERE ProductID = @ProductID";
                        using (var updateProductCommand = new SqlCommand(updateProductQuery, connection))
                        {
                            updateProductCommand.Parameters.AddWithValue("@QuantityDifference", quantityDifference);
                            updateProductCommand.Parameters.AddWithValue("@ProductID", selectedDetail.ProductID);
                            updateProductCommand.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Update", "PurchaseOrderDetails", $"Updated Purchase Order Detail for Product ID: {selectedDetail.ProductID}");
                    StatusTextBlock.Text = "Purchase order detail updated successfully.";
                    InitializePlaceholders();
                    LoadPurchaseOrderDetails();
                }
                catch (Exception ex)
                {
                    StatusTextBlock.Text = $"Error updating purchase order detail: {ex.Message}";
                }
            }
            else
            {
                StatusTextBlock.Text = "Select a purchase order detail to update.";
            }
        }


        private void DeletePurchaseOrderDetail_Click(object sender, RoutedEventArgs e)
        {
            if (PurchaseOrderDetailsDataGrid.SelectedItem is PurchaseOrderDetailItem selectedDetail)
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM PurchaseOrderDetails WHERE PODetailID = @PODetailID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@PODetailID", selectedDetail.PODetailID);
                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Delete", "PurchaseOrderDetails", $"Deleted Purchase Order Detail ID: {selectedDetail.PODetailID}");
                    StatusTextBlock.Text = "Purchase order detail deleted successfully.";
                    InitializePlaceholders();
                    LoadPurchaseOrderDetails();
                }
                catch (Exception ex)
                {
                    StatusTextBlock.Text = $"Error deleting purchase order detail: {ex.Message}";
                }
            }
            else
            {
                StatusTextBlock.Text = "Select a purchase order detail to delete.";
            }
        }

        private void PurchaseOrderDetailsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PurchaseOrderDetailsDataGrid.SelectedItem is PurchaseOrderDetailItem selectedDetail)
            {
                QuantityTextBox.Text = selectedDetail.Quantity.ToString();
                UnitPriceTextBox.Text = selectedDetail.UnitPrice.ToString("F2");
                PurchaseOrderIDTextBox.Text = selectedDetail.PurchaseOrderID.ToString();
                ProductIDTextBox.Text = selectedDetail.ProductID.ToString();
            }
        }
    }

    public class PurchaseOrderDetailItem
    {
        public int PODetailID { get; set; }
        public int PurchaseOrderID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    }
}
