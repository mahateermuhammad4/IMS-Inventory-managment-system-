﻿using System;
using System.Collections.Generic;
using   Microsoft.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Data;

namespace InventoryApp
{
    public partial class Dashboard : Window
    {
        private int currentUserId;
        private string currentUserRole; 

        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True;";
    
        public Dashboard(int userId, string userRole) 
        {
            InitializeComponent();
            currentUserId = userId;
            currentUserRole = userRole; 
            LoadLowStockItems();
            LoadMetrics();

            
            ControlAccess();
        }

        private void LoadMetrics()
        {
            var (totalSales, totalPurchases, totalOrders) = GetMetrics();
            TotalSalesTextBlock.Text = $" ${totalSales:N2}";
            TotalPurchasesTextBlock.Text = $" ${totalPurchases:N2}";
            TotalOrdersTextBlock.Text = $" {totalOrders} Orders";
        }

        private (decimal totalSales, decimal totalPurchases, int totalOrders) GetMetrics()
        {
            decimal totalSales = 0;
            decimal totalPurchases = 0;
            int totalOrders = 0;

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Total Sales
                using (var command = new SqlCommand("SELECT SUM(TotalAmount) FROM SalesOrders WHERE Status = 'Shipped'", connection))
                {
                    var result = command.ExecuteScalar();
                    totalSales = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                }

                // Total Purchases
                using (var command = new SqlCommand("SELECT SUM(TotalAmount) FROM PurchaseOrders WHERE Status = 'Completed'", connection))
                {
                    var result = command.ExecuteScalar();
                    totalPurchases = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                }

                // Total Orders
                using (var command = new SqlCommand(@"
                    SELECT 
                        (SELECT COUNT(*) FROM SalesOrders WHERE Status = 'Shipped') +
                        (SELECT COUNT(*) FROM PurchaseOrders WHERE Status = 'Completed')", connection))
                {
                    totalOrders = (int)command.ExecuteScalar();
                }
            }

            return (totalSales, totalPurchases, totalOrders);
        }



        private void ControlAccess()
        {
            if (currentUserRole == "Admin")
            {
               
                FeaturesButton.Visibility = Visibility.Visible;
                ReportsButton.Visibility = Visibility.Visible;
               
            }
            else if (currentUserRole == "Manager")
            {
                
                FeaturesButton.Visibility = Visibility.Visible; 
                ReportsButton.Visibility = Visibility.Visible; 

            }
            else if (currentUserRole == "Staff")
            {     
                FeaturesButton.Visibility = Visibility.Visible; 
                ReportsButton.Visibility = Visibility.Collapsed; 
            }
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            var reportWindow = new Window
            {
                Title = "Reports and Analytics",
                Width = 800,
                Height = 600,
                Background = System.Windows.Media.Brushes.BurlyWood
            };

           
            var tabControl = new TabControl
            {
                Margin = new Thickness(10),
                Padding = new Thickness(5)
            };

           
            var inventoryTab = new TabItem { Header = "Inventory Valuation" };
            inventoryTab.Content = GenerateInventoryValuationReport();
            tabControl.Items.Add(inventoryTab);

            var stockMovementTab = new TabItem { Header = "Stock Movement" };
            stockMovementTab.Content = GenerateStockMovementReport();
            tabControl.Items.Add(stockMovementTab);

            var salesPurchaseTab = new TabItem { Header = "Sales & Purchase" };
            salesPurchaseTab.Content = GenerateSalesPurchaseReport();
            tabControl.Items.Add(salesPurchaseTab);

            var demandForecastingTab = new TabItem { Header = "Demand Forecasting" };
            demandForecastingTab.Content = GenerateDemandForecastingReport();
            tabControl.Items.Add(demandForecastingTab);

            reportWindow.Content = tabControl;
            reportWindow.ShowDialog();
        }


        private DataGrid GenerateInventoryValuationReport()
        {
            var dataGrid = new DataGrid();
            string query = "SELECT Name, Quantity, UnitPrice, (Quantity * UnitPrice) AS TotalValue FROM Products";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(reader);
                        dataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error fetching inventory valuation: {ex.Message}");
            }

            return dataGrid;
        }

        private DataGrid GenerateStockMovementReport()
        {
            var dataGrid = new DataGrid();
            string query = "SELECT ProductID, MovementType, Quantity, MovementDate, Description FROM StockMovements";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(reader);
                        dataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error fetching stock movements: {ex.Message}");
            }

            return dataGrid;
        }

        private DataGrid GenerateSalesPurchaseReport()
        {
            var dataGrid = new DataGrid();
            string query = @"SELECT p.ProductID, p.Name, SUM(sod.Quantity) AS TotalSold, SUM(pod.Quantity) AS TotalPurchased
                             FROM Products p
                             LEFT JOIN SalesOrderDetails sod ON p.ProductID = sod.ProductID
                             LEFT JOIN PurchaseOrderDetails pod ON p.ProductID = pod.ProductID
                             GROUP BY p.ProductID, p.Name";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(reader);
                        dataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error fetching sales and purchase data: {ex.Message}");
            }

            return dataGrid;
        }

        private TextBlock GenerateDemandForecastingReport()
        {
            var textBlock = new TextBlock
            {
                Text = "Demand Forecasting functionality is under development.",
                FontSize = 16,
                Foreground = System.Windows.Media.Brushes.DarkSlateGray,
                TextWrapping = TextWrapping.Wrap
            };

          
            return textBlock;
        }


   
        private void LoadLowStockItems()
        {
            var lowStockProducts = new List<Product>();
            string connectionString  = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True;"; 

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Products WHERE Quantity < 10"; 
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var product = new Product
                            {
                                ProductID = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                SKU = reader.GetString(2),
                                Category = reader.IsDBNull(3) ? null : reader.GetString(3),
                                Quantity = reader.GetInt32(4),
                                UnitPrice = reader.IsDBNull(5) ? 0 : reader.GetDecimal(5),
                                Barcode = reader.IsDBNull(6) ? null : reader.GetString(6)
                            };
                            lowStockProducts.Add(product);
                        }
                    }
                }

               
                DisplayLowStockItems(lowStockProducts);
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
        }


        private void DisplayLowStockItems(List<Product> lowStockProducts)
        {
            // Clear the existing items in the ListBox
            LowStockItemsListBox.Items.Clear();

            if (lowStockProducts.Count > 0)
            {
                LowStockTextBlock.Text = "Low Stock Items:";

                // Loop through each product and add it to the ListBox
                foreach (var product in lowStockProducts)
                {
                    LowStockItemsListBox.Items.Add(new LowStockItem
                    {
                        Name = $"{product.Name} (ID: {product.ProductID}, Quantity: {product.Quantity})"
                    });
                }
            }
            else
            {
                LowStockTextBlock.Text = "No low stock items.";
            }
        }

        // Define a class for low stock items
        public class LowStockItem
        {
            public string Name { get; set; }
        }



        private void Products_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new Productcontrol(currentUserId);
           
        }

      
        private void Suppliers_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new SupplierControl(currentUserId);
        }

       
        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new OrderControl(currentUserId);
        }

        private List<string> notifications = new List<string>();

        public class PurchaseOrder
        {
            public int PurchaseOrderID { get; set; }
            public int SupplierID { get; set; }
            public DateTime OrderDate { get; set; }
            public string Status { get; set; }
            public decimal TotalAmount { get; set; }
        }

       

      



        private void Features_Click(object sender, RoutedEventArgs e)
        {
            Features featuresWindow = new Features(currentUserRole);
            featuresWindow.ShowDialog();
        }
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string input = SearchInput.Text?.Trim();

            if (string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Please enter a Product ID or Barcode to search.", "Input Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if input is numeric (Product ID) or string (Barcode)
                    bool isNumeric = int.TryParse(input, out int productId);
                    string query;

                    if (isNumeric)
                    {
                        query = "SELECT * FROM Products WHERE ProductID = @Input";
                    }
                    else
                    {
                        query = "SELECT * FROM Products WHERE Barcode = @Input";
                    }

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Input", input);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string productName = reader["Name"].ToString();
                                int quantity = Convert.ToInt32(reader["Quantity"]);
                                MessageBox.Show($"Product Found: {productName}, Quantity: {quantity}", "Search Result", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                MessageBox.Show("No product found with the given ID or Barcode.", "Not Found", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SalesOrders_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new SalesOrdercontrol(currentUserId);
        }

        private void PO_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new POdetails(currentUserId);
        }
        private void SO_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new SOdetails(currentUserId);
        }

        private void InfoButton_Click(object sender, RoutedEventArgs e)
        {
            string message = "Welcome to MAG Haven Inventory Management System.\n\n" +
                             "For assistance, please contact:\n" +
                             "Email: 233539@students.au.edu.pk\n" +
                             "Email: 233577@students.au.edu.pk\n" +
                             "Email: 233523@students.au.edu.pk\n\n" +
                             "Did you know?\nMAG Haven helps manage inventory efficiently and reduces errors through " +
                             "streamlined processes.";
            MessageBox.Show(message, "Help and Fact", MessageBoxButton.OK, MessageBoxImage.Information);
        }

    
    }


    public class Product
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string SKU { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string Barcode { get; set; }
    }
}
