﻿using System;
using System.Collections.Generic;
using   Microsoft.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Data;

namespace InventoryApp
{
    public partial class Dashboard : Window
    {
        private int currentUserId;
        private string currentUserRole; // Store user role

        public Dashboard(int userId, string userRole) // Modify constructor to accept userRole
        {
            InitializeComponent();
            currentUserId = userId;
            currentUserRole = userRole; // Store the user role
            LoadLowStockItems();
           

            // Control access based on role
            ControlAccess();
        }
        private void ControlAccess()
        {
            if (currentUserRole == "Admin")
            {
               
                FeaturesButton.Visibility = Visibility.Visible;
                ReportsButton.Visibility = Visibility.Visible;
               
            }
            else if (currentUserRole == "Manager")
            {
                
                FeaturesButton.Visibility = Visibility.Visible; 
                ReportsButton.Visibility = Visibility.Visible; 

            }
            else if (currentUserRole == "Staff")
            {     
                FeaturesButton.Visibility = Visibility.Visible; 
                ReportsButton.Visibility = Visibility.Collapsed; 
            }
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            var reportWindow = new Window
            {
                Title = "Reports and Analytics",
                Width = 800,
                Height = 600,
                Background = System.Windows.Media.Brushes.BurlyWood
            };

           
            var tabControl = new TabControl
            {
                Margin = new Thickness(10),
                Padding = new Thickness(5)
            };

           
            var inventoryTab = new TabItem { Header = "Inventory Valuation" };
            inventoryTab.Content = GenerateInventoryValuationReport();
            tabControl.Items.Add(inventoryTab);

            var stockMovementTab = new TabItem { Header = "Stock Movement" };
            stockMovementTab.Content = GenerateStockMovementReport();
            tabControl.Items.Add(stockMovementTab);

            var salesPurchaseTab = new TabItem { Header = "Sales & Purchase" };
            salesPurchaseTab.Content = GenerateSalesPurchaseReport();
            tabControl.Items.Add(salesPurchaseTab);

            var demandForecastingTab = new TabItem { Header = "Demand Forecasting" };
            demandForecastingTab.Content = GenerateDemandForecastingReport();
            tabControl.Items.Add(demandForecastingTab);

            reportWindow.Content = tabControl;
            reportWindow.ShowDialog();
        }


        private DataGrid GenerateInventoryValuationReport()
        {
            var dataGrid = new DataGrid();
            string query = "SELECT Name, Quantity, UnitPrice, (Quantity * UnitPrice) AS TotalValue FROM Products";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(reader);
                        dataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error fetching inventory valuation: {ex.Message}");
            }

            return dataGrid;
        }

        private DataGrid GenerateStockMovementReport()
        {
            var dataGrid = new DataGrid();
            string query = "SELECT ProductID, MovementType, Quantity, MovementDate, Description FROM StockMovements";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(reader);
                        dataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error fetching stock movements: {ex.Message}");
            }

            return dataGrid;
        }

        private DataGrid GenerateSalesPurchaseReport()
        {
            var dataGrid = new DataGrid();
            string query = @"SELECT p.ProductID, p.Name, SUM(sod.Quantity) AS TotalSold, SUM(pod.Quantity) AS TotalPurchased
                             FROM Products p
                             LEFT JOIN SalesOrderDetails sod ON p.ProductID = sod.ProductID
                             LEFT JOIN PurchaseOrderDetails pod ON p.ProductID = pod.ProductID
                             GROUP BY p.ProductID, p.Name";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(reader);
                        dataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error fetching sales and purchase data: {ex.Message}");
            }

            return dataGrid;
        }

        private TextBlock GenerateDemandForecastingReport()
        {
            var textBlock = new TextBlock
            {
                Text = "Demand Forecasting functionality is under development.",
                FontSize = 16,
                Foreground = System.Windows.Media.Brushes.DarkSlateGray,
                TextWrapping = TextWrapping.Wrap
            };

          
            return textBlock;
        }

        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True;";
    

   
        private void LoadLowStockItems()
        {
            var lowStockProducts = new List<Product>();
            string connectionString  = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True;"; 

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Products WHERE Quantity < 10"; 
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var product = new Product
                            {
                                ProductID = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                SKU = reader.GetString(2),
                                Category = reader.IsDBNull(3) ? null : reader.GetString(3),
                                Quantity = reader.GetInt32(4),
                                UnitPrice = reader.IsDBNull(5) ? 0 : reader.GetDecimal(5),
                                Barcode = reader.IsDBNull(6) ? null : reader.GetString(6)
                            };
                            lowStockProducts.Add(product);
                        }
                    }
                }

               
                DisplayLowStockItems(lowStockProducts);
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
        }

      
        private void DisplayLowStockItems(List<Product> lowStockProducts)
        {
            if (lowStockProducts.Count > 0)
            {
                LowStockTextBlock.Text = "Low Stock Items:";
                foreach (var product in lowStockProducts)
                {
                    LowStockTextBlock.Text += $"\n- {product.Name} (ID: {product.ProductID}, Quantity: {product.Quantity})";
                }
            }
            else
            {
                LowStockTextBlock.Text = "No low stock items.";
            }
        }

       
        private void Products_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new Productcontrol(currentUserId);
           
        }

      
        private void Suppliers_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new SupplierControl(currentUserId);
        }

       
        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new OrderControl(currentUserId);
        }

        private List<string> notifications = new List<string>();

        public class PurchaseOrder
        {
            public int PurchaseOrderID { get; set; }
            public int SupplierID { get; set; }
            public DateTime OrderDate { get; set; }
            public string Status { get; set; }
            public decimal TotalAmount { get; set; }
        }

       

      



        private void Features_Click(object sender, RoutedEventArgs e)
        {
            Features featuresWindow = new Features(currentUserRole);
            featuresWindow.ShowDialog();
        }
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string input = SearchInput.Text?.Trim();

            if (string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Please enter a Product ID or Barcode to search.", "Input Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if input is numeric (Product ID) or string (Barcode)
                    bool isNumeric = int.TryParse(input, out int productId);
                    string query;

                    if (isNumeric)
                    {
                        query = "SELECT * FROM Products WHERE ProductID = @Input";
                    }
                    else
                    {
                        query = "SELECT * FROM Products WHERE Barcode = @Input";
                    }

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Input", input);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string productName = reader["Name"].ToString();
                                int quantity = Convert.ToInt32(reader["Quantity"]);
                                MessageBox.Show($"Product Found: {productName}, Quantity: {quantity}", "Search Result", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                MessageBox.Show("No product found with the given ID or Barcode.", "Not Found", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

       

    }


    public class Product
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string SKU { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string Barcode { get; set; }
    }
}
