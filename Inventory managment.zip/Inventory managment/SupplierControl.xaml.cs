﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using Microsoft.Identity.Client.Extensibility;

namespace InventoryApp
{
    public partial class SupplierControl : UserControl
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";
        private List<Supplier> suppliers;
        private int currentuserid=1;
        public SupplierControl(int currentuserid)
        {
            InitializeComponent();
            LoadSuppliers();
            this.currentuserid = currentuserid;
        }

        public class Supplier
        {
            public int SupplierID { get; set; }
            public string SupplierName { get; set; }
            public string ContactName { get; set; }
            public string Phone { get; set; }
            public string Email { get; set; }
        }

        private void LoadSuppliers()
        {
            suppliers = new List<Supplier>();

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SupplierID, SupplierName, ContactName, Phone, Email FROM Suppliers";
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var supplier = new Supplier
                        {
                            SupplierID = reader.GetInt32(reader.GetOrdinal("SupplierID")),
                            SupplierName = reader.GetString(reader.GetOrdinal("SupplierName")),
                            ContactName = reader.GetString(reader.GetOrdinal("ContactName")),
                            Phone = reader.GetString(reader.GetOrdinal("Phone")),
                            Email = reader.GetString(reader.GetOrdinal("Email")),
                        };
                        suppliers.Add(supplier);
                    }
                }
            }

            SuppliersDataGrid.ItemsSource = suppliers;
        }

        private void AddSupplier_Click(object sender, RoutedEventArgs e)
        {
            var newSupplier = new Supplier
            {
                SupplierName = SupplierNameTextBox.Text,
                ContactName = ContactNameTextBox.Text,
                Phone = PhoneTextBox.Text,
                Email = EmailTextBox.Text
            };

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Suppliers (SupplierName, ContactName, Phone, Email) VALUES (@SupplierName, @ContactName, @Phone, @Email)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SupplierName", newSupplier.SupplierName);
                    command.Parameters.AddWithValue("@ContactName", newSupplier.ContactName);
                    command.Parameters.AddWithValue("@Phone", newSupplier.Phone);
                    command.Parameters.AddWithValue("@Email", newSupplier.Email);
                    command.ExecuteNonQuery();
                }
            }

            LogAudit(currentuserid, "Add", "Suppliers", $"Added Supplier: {newSupplier.SupplierName}");
            MessageBox.Show("Supplier added successfully!");
            ClearInputs();
            LoadSuppliers();
        }

        private void UpdateSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem is Supplier selectedSupplier)
            {
                selectedSupplier.SupplierName = SupplierNameTextBox.Text;
                selectedSupplier.ContactName = ContactNameTextBox.Text;
                selectedSupplier.Phone = PhoneTextBox.Text;
                selectedSupplier.Email = EmailTextBox.Text;

                using (var connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string query = "UPDATE Suppliers SET SupplierName = @SupplierName, ContactName = @ContactName, Phone = @Phone, Email = @Email WHERE SupplierID = @SupplierID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@SupplierID", selectedSupplier.SupplierID);
                            command.Parameters.AddWithValue("@SupplierName", selectedSupplier.SupplierName);
                            command.Parameters.AddWithValue("@ContactName", selectedSupplier.ContactName);
                            command.Parameters.AddWithValue("@Phone", selectedSupplier.Phone);
                            command.Parameters.AddWithValue("@Email", selectedSupplier.Email);
                            command.ExecuteNonQuery();
                        }
                    }
                    catch (SqlException ex)
                    {
                        StatusTextBlock.Text = "Error adding order: " + ex.Message;
                    }
                        
                }

                LogAudit(currentuserid, "Update", "Suppliers", $"Updated Supplier ID: {selectedSupplier.SupplierID}");
                MessageBox.Show("Supplier updated successfully!");
                ClearInputs();
                LoadSuppliers();
            }
            else
            {
                MessageBox.Show("Please select a supplier to update.");
            }
        }

        private void DeleteSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem is Supplier selectedSupplier)
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Suppliers WHERE SupplierID = @SupplierID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@SupplierID", selectedSupplier.SupplierID);
                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentuserid, "Delete", "Suppliers", $"Deleted Supplier ID: {selectedSupplier.SupplierID}");
                    MessageBox.Show("Supplier deleted successfully!");
                    ClearInputs();
                    LoadSuppliers();
                }
                catch (SqlException ex)
                {
                    StatusTextBlock.Text = "Error adding order: " + ex.Message;
                }
                catch (Exception ex)
                {
                    StatusTextBlock.Text = "Error adding order: " + ex.Message;
                }
            }
            else
            {
                MessageBox.Show("Please select a supplier to delete.");
            }
        }

        private void SuppliersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem is Supplier selectedSupplier)
            {
                SupplierNameTextBox.Text = selectedSupplier.SupplierName;
                ContactNameTextBox.Text = selectedSupplier.ContactName;
                PhoneTextBox.Text = selectedSupplier.Phone;
                EmailTextBox.Text = selectedSupplier.Email;
            }
        }

        private void ClearInputs()
        {
            SupplierNameTextBox.Clear();
            ContactNameTextBox.Clear();
            PhoneTextBox.Clear();
            EmailTextBox.Clear();
        }

        private void LogAudit(int userId, string action, string tableAffected, string description)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime,Description) VALUES (@UserID, @Action, @TableAffected, @Description, @Timestamp)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Action", action);
                        command.Parameters.AddWithValue("@TableAffected", tableAffected); // You can change this if necessary
                        command.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", description);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                // Handle SQL exceptions (e.g., log the error message)
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                // Handle general exceptions
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}
