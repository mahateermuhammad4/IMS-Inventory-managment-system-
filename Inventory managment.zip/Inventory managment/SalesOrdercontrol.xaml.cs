﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace InventoryApp
{
    public partial class SalesOrdercontrol : UserControl
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";
        private int currentUserId;

        public SalesOrdercontrol(int userid)
        {
            InitializeComponent();
            currentUserId = userid;
            LoadSalesOrders();
        }

        private void LoadSalesOrders()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SalesOrderID, CustomerName, OrderDate, Status, TotalAmount FROM SalesOrders";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable salesOrders = new DataTable();
                    adapter.Fill(salesOrders);
                    SalesOrdersDataGrid.ItemsSource = salesOrders.DefaultView;

                    LogAudit(currentUserId, "View", "SalesOrders", "Loaded all sales orders.");
                }

                StatusTextBlock.Text = "Sales orders loaded successfully.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading sales orders: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LogAudit(int userId, string action, string tableAffected, string description)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime, Description) " +
                                   "VALUES (@UserID, @Action, @TableAffected, @ActionTime, @Description)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Action", action);
                        command.Parameters.AddWithValue("@TableAffected", tableAffected);
                        command.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", description);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string customerName = CustomerNameTextBox.Text;
                DateTime orderDate = OrderDatePicker.SelectedDate ?? DateTime.Now;
                string status = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                decimal totalAmount;

                if (string.IsNullOrWhiteSpace(customerName) || status == null || !decimal.TryParse(TotalAmountTextBox.Text, out totalAmount))
                {
                    StatusTextBlock.Text = "Please fill in all fields correctly.";
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO SalesOrders (CustomerName, OrderDate, Status, TotalAmount) " +
                                   "OUTPUT INSERTED.SalesOrderID VALUES (@CustomerName, @OrderDate, @Status, @TotalAmount)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CustomerName", customerName);
                        command.Parameters.AddWithValue("@OrderDate", orderDate);
                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@TotalAmount", totalAmount);

                        int insertedId = (int)command.ExecuteScalar();
                        LogAudit(currentUserId, "Add", "SalesOrders", $"Added Sales Order ID {insertedId} for {customerName}");
                    }
                }

                StatusTextBlock.Text = "Order added successfully.";
                LoadSalesOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding order: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateOrder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (SalesOrdersDataGrid.SelectedItem == null)
                {
                    StatusTextBlock.Text = "Select an order to update.";
                    return;
                }

                DataRowView selectedRow = (DataRowView)SalesOrdersDataGrid.SelectedItem;
                int salesOrderId = (int)selectedRow["SalesOrderID"];
                string customerName = CustomerNameTextBox.Text;
                DateTime orderDate = OrderDatePicker.SelectedDate ?? DateTime.Now;
                string status = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                decimal totalAmount;

                if (string.IsNullOrWhiteSpace(customerName) || status == null || !decimal.TryParse(TotalAmountTextBox.Text, out totalAmount))
                {
                    StatusTextBlock.Text = "Please fill in all fields correctly.";
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE SalesOrders SET CustomerName = @CustomerName, OrderDate = @OrderDate, " +
                                   "Status = @Status, TotalAmount = @TotalAmount WHERE SalesOrderID = @SalesOrderID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SalesOrderID", salesOrderId);
                        command.Parameters.AddWithValue("@CustomerName", customerName);
                        command.Parameters.AddWithValue("@OrderDate", orderDate);
                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@TotalAmount", totalAmount);
                        command.ExecuteNonQuery();

                        LogAudit(currentUserId, "Update", "SalesOrders", $"Updated Sales Order ID {salesOrderId} for {customerName}");
                    }
                }

                StatusTextBlock.Text = "Order updated successfully.";
                LoadSalesOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating order: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (SalesOrdersDataGrid.SelectedItem == null)
                {
                    StatusTextBlock.Text = "Select an order to delete.";
                    return;
                }

                DataRowView selectedRow = (DataRowView)SalesOrdersDataGrid.SelectedItem;
                int salesOrderId = (int)selectedRow["SalesOrderID"];

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM SalesOrders WHERE SalesOrderID = @SalesOrderID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SalesOrderID", salesOrderId);
                        command.ExecuteNonQuery();

                        LogAudit(currentUserId, "Delete", "SalesOrders", $"Deleted Sales Order ID {salesOrderId}");
                    }
                }

                StatusTextBlock.Text = "Order deleted successfully.";
                LoadSalesOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting order: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SalesOrdersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SalesOrdersDataGrid.SelectedItem == null) return;

            DataRowView selectedRow = (DataRowView)SalesOrdersDataGrid.SelectedItem;
            CustomerNameTextBox.Text = selectedRow["CustomerName"].ToString();
            OrderDatePicker.SelectedDate = (DateTime)selectedRow["OrderDate"];
            StatusComboBox.SelectedItem = selectedRow["Status"].ToString();
            TotalAmountTextBox.Text = selectedRow["TotalAmount"].ToString();
        }

        private void CustomerNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

    }
}
