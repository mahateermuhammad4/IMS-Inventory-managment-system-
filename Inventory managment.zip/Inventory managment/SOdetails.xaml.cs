﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace InventoryApp
{
    public partial class SOdetails : UserControl
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";
        private int currentUserId;

        public SOdetails(int userId)
        {
            InitializeComponent();
            LoadSalesOrderDetails();
            InitializePlaceholders();
            currentUserId = userId;
        }

        private void LogAudit(int userId, string action, string tableAffected, string description)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime, Description) VALUES (@UserID, @Action, @TableAffected, @ActionTime, @Description)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Action", action);
                        command.Parameters.AddWithValue("@TableAffected", tableAffected);
                        command.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", description);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void InitializePlaceholders()
        {
            QuantityTextBox.Text = "Enter Quantity";
            UnitPriceTextBox.Text = "Enter Unit Price";
        }

        private void LoadSalesOrderDetails()
        {
            var salesOrderDetails = new List<SalesOrderDetailItem>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SODetailID, SalesOrderID, ProductID, Quantity, UnitPrice FROM SalesOrderDetails";
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var detail = new SalesOrderDetailItem
                            {
                                SODetailID = Convert.ToInt32(reader["SODetailID"]),
                                SalesOrderID = Convert.ToInt32(reader["SalesOrderID"]),
                                ProductID = Convert.ToInt32(reader["ProductID"]),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                UnitPrice = Convert.ToDecimal(reader["UnitPrice"]),
                            };
                            salesOrderDetails.Add(detail);
                        }
                    }
                }

                SalesOrderDetailsDataGrid.ItemsSource = salesOrderDetails;
                StatusTextBlock.Text = $"Loaded {salesOrderDetails.Count} sales order details.";
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Error loading sales order details: {ex.Message}";
            }
        }

        private void AddSalesOrderDetail_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(QuantityTextBox.Text, out var quantity) ||
                !decimal.TryParse(UnitPriceTextBox.Text, out var unitPrice) ||
                string.IsNullOrWhiteSpace(SalesOrderIDTextBox.Text) ||
                string.IsNullOrWhiteSpace(ProductIDTextBox.Text))
            {
                StatusTextBlock.Text = "Sales Order ID, Product ID, Quantity, and Unit Price are required.";
                return;
            }

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    
                    string orderStatusQuery = "SELECT Status FROM SalesOrders WHERE SalesOrderID = @SalesOrderID";
                    string orderStatus = null;

                    using (var statusCommand = new SqlCommand(orderStatusQuery, connection))
                    {
                        statusCommand.Parameters.AddWithValue("@SalesOrderID", SalesOrderIDTextBox.Text.Trim());
                        orderStatus = (string)statusCommand.ExecuteScalar();
                    }

                    if (orderStatus == null)
                    {
                        StatusTextBlock.Text = "Sales Order not found.";
                        return;
                    }

                    if (orderStatus == "Cancelled")
                    {
                        StatusTextBlock.Text = "Cannot add details to a cancelled sales order.";
                        return;
                    }

                   
                    string productQuery = "SELECT Quantity FROM Products WHERE ProductID = @ProductID";
                    int availableQuantity = 0;

                    using (var productCommand = new SqlCommand(productQuery, connection))
                    {
                        productCommand.Parameters.AddWithValue("@ProductID", ProductIDTextBox.Text.Trim());
                        var result = productCommand.ExecuteScalar();

                        if (result != null)
                        {
                            availableQuantity = Convert.ToInt32(result);
                        }
                        else
                        {
                            StatusTextBlock.Text = "Product not found.";
                            return;
                        }
                    }

                    if (quantity > availableQuantity)
                    {
                        StatusTextBlock.Text = "Insufficient quantity available for this product.";
                        return;
                    }

                   
                    string insertQuery = "INSERT INTO SalesOrderDetails (SalesOrderID, ProductID, Quantity, UnitPrice) VALUES (@SalesOrderID, @ProductID, @Quantity, @UnitPrice)";
                    using (var insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@SalesOrderID", SalesOrderIDTextBox.Text.Trim());
                        insertCommand.Parameters.AddWithValue("@ProductID", ProductIDTextBox.Text.Trim());
                        insertCommand.Parameters.AddWithValue("@Quantity", quantity);
                        insertCommand.Parameters.AddWithValue("@UnitPrice", unitPrice);

                        insertCommand.ExecuteNonQuery();
                    }

                    
                    string updateProductQuery = "UPDATE Products SET Quantity = Quantity - @Quantity WHERE ProductID = @ProductID";
                    using (var updateCommand = new SqlCommand(updateProductQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@Quantity", quantity);
                        updateCommand.Parameters.AddWithValue("@ProductID", ProductIDTextBox.Text.Trim());

                        updateCommand.ExecuteNonQuery();
                    }
                }

                LogAudit(currentUserId, "Add", "SalesOrderDetails", $"Added Sales Order Detail for Product ID: {ProductIDTextBox.Text}");
                StatusTextBlock.Text = "Sales order detail added successfully.";
                InitializePlaceholders();
                LoadSalesOrderDetails();
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Error adding sales order detail: {ex.Message}";
            }
        }


        private void UpdateSalesOrderDetail_Click(object sender, RoutedEventArgs e)
        {
            if (SalesOrderDetailsDataGrid.SelectedItem is SalesOrderDetailItem selectedDetail)
            {
                if (!int.TryParse(QuantityTextBox.Text, out var newQuantity) || newQuantity < 0 ||
                    !decimal.TryParse(UnitPriceTextBox.Text, out var unitPrice))
                {
                    StatusTextBlock.Text = "Quantity must be a non-negative number, and Unit Price is required.";
                    return;
                }

                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        int currentQuantity = selectedDetail.Quantity;

                        
                        if (newQuantity > currentQuantity)
                        {
                            int quantityDifference = newQuantity - currentQuantity;

                            
                            string productQuery = "SELECT Quantity FROM Products WHERE ProductID = @ProductID";
                            int availableQuantity = 0;

                            using (var productCommand = new SqlCommand(productQuery, connection))
                            {
                                productCommand.Parameters.AddWithValue("@ProductID", selectedDetail.ProductID);
                                var result = productCommand.ExecuteScalar();

                                if (result != null)
                                {
                                    availableQuantity = Convert.ToInt32(result);
                                }
                                else
                                {
                                    StatusTextBlock.Text = "Product not found.";
                                    return;
                                }
                            }

                            if (quantityDifference > availableQuantity)
                            {
                                StatusTextBlock.Text = "Insufficient quantity available for this product.";
                                return;
                            }

                           
                            string updateProductQuery = "UPDATE Products SET Quantity = Quantity - @QuantityDifference WHERE ProductID = @ProductID";
                            using (var updateProductCommand = new SqlCommand(updateProductQuery, connection))
                            {
                                updateProductCommand.Parameters.AddWithValue("@QuantityDifference", quantityDifference);
                                updateProductCommand.Parameters.AddWithValue("@ProductID", selectedDetail.ProductID);
                                updateProductCommand.ExecuteNonQuery();
                            }
                        }
                        else if (newQuantity < currentQuantity)
                        {
                            int quantityDifference = currentQuantity - newQuantity;

                            
                            string updateProductQuery = "UPDATE Products SET Quantity = Quantity + @QuantityDifference WHERE ProductID = @ProductID";
                            using (var updateProductCommand = new SqlCommand(updateProductQuery, connection))
                            {
                                updateProductCommand.Parameters.AddWithValue("@QuantityDifference", quantityDifference);
                                updateProductCommand.Parameters.AddWithValue("@ProductID", selectedDetail.ProductID);
                                updateProductCommand.ExecuteNonQuery();
                            }
                        }

                       
                        string updateQuery = "UPDATE SalesOrderDetails SET Quantity = @Quantity, UnitPrice = @UnitPrice WHERE SODetailID = @SODetailID";
                        using (var updateCommand = new SqlCommand(updateQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@SODetailID", selectedDetail.SODetailID);
                            updateCommand.Parameters.AddWithValue("@Quantity", newQuantity);
                            updateCommand.Parameters.AddWithValue("@UnitPrice", unitPrice);
                            updateCommand.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Update", "SalesOrderDetails", $"Updated Sales Order Detail for Product ID: {selectedDetail.ProductID}");
                    StatusTextBlock.Text = "Sales order detail updated successfully.";
                    InitializePlaceholders();
                    LoadSalesOrderDetails();
                }
                catch (Exception ex)
                {
                    StatusTextBlock.Text = $"Error updating sales order detail: {ex.Message}";
                }
            }
            else
            {
                StatusTextBlock.Text = "Select a sales order detail to update.";
            }
        }


        private void DeleteSalesOrderDetail_Click(object sender, RoutedEventArgs e)
        {
            if (SalesOrderDetailsDataGrid.SelectedItem is SalesOrderDetailItem selectedDetail)
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM SalesOrderDetails WHERE SODetailID = @SODetailID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@SODetailID", selectedDetail.SODetailID);
                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Delete", "SalesOrderDetails", $"Deleted Sales Order Detail ID: {selectedDetail.SODetailID}");
                    StatusTextBlock.Text = "Sales order detail deleted successfully.";
                    InitializePlaceholders();
                    LoadSalesOrderDetails();
                }
                catch (Exception ex)
                {
                    StatusTextBlock.Text = $"Error deleting sales order detail: {ex.Message}";
                }
            }
            else
            {
                StatusTextBlock.Text = "Select a sales order detail to delete.";
            }
        }

        private void SalesOrderDetailsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SalesOrderDetailsDataGrid.SelectedItem is SalesOrderDetailItem selectedDetail)
            {
                QuantityTextBox.Text = selectedDetail.Quantity.ToString();
                UnitPriceTextBox.Text = selectedDetail.UnitPrice.ToString("F2");
                SalesOrderIDTextBox.Text = selectedDetail.SalesOrderID.ToString();
                ProductIDTextBox.Text = selectedDetail.ProductID.ToString();
            }
        }
    }

    public class SalesOrderDetailItem
    {
        public int SODetailID { get; set; }
        public int SalesOrderID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    }
}
