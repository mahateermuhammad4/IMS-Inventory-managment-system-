﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace InventoryApp
{
    public partial class OrderControl : UserControl
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";

        private int currentUserId = 1;

        public OrderControl(int userid)
        {
            InitializeComponent();
            LoadOrders();
            InitializePlaceholders();
            currentUserId = userid;
        }

        private void LogAudit(int userId, string action, string tableAffected, string description)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime, Description) VALUES (@UserID, @Action, @TableAffected, @ActionTime, @Description)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Action", action);
                        command.Parameters.AddWithValue("@TableAffected", tableAffected);
                        command.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", description);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void InitializePlaceholders()
        {
            OrderIdTextBox.Text = "Enter Order ID";
            OrderDetailsTextBox.Text = "Enter Order Details";
            TotalAmountTextBox.Text = "Enter Total Amount";
            StatusTextBox.Text = "Enter Status";
        }

        private void LoadOrders()
        {
            var orders = new List<PurchaseOrder>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM PurchaseOrders";
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var order = new PurchaseOrder
                            {
                                PurchaseOrderID = reader.GetInt32(0),
                                SupplierID = reader.GetInt32(1),
                                OrderDate = reader.GetDateTime(2),
                                Status = reader.GetString(3),
                                TotalAmount = reader.GetDecimal(4)
                            };
                            orders.Add(order);
                        }
                    }
                }

                OrdersDataGrid.ItemsSource = orders;
            }
            catch (SqlException ex)
            {
                StatusTextBlock.Text = "Error loading orders: " + ex.Message;
            }
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            // Validate SupplierID input
            if (string.IsNullOrWhiteSpace(OrderIdTextBox.Text) || !int.TryParse(OrderIdTextBox.Text, out int supplierID))
            {
                StatusTextBlock.Text = "Error: Invalid Supplier ID. Please enter a valid number.";
                return;
            }

            // Validate TotalAmount input
            if (string.IsNullOrWhiteSpace(TotalAmountTextBox.Text) || !decimal.TryParse(TotalAmountTextBox.Text, out decimal totalAmount))
            {
                StatusTextBlock.Text = "Error: Invalid Total Amount. Please enter a valid number.";
                return;
            }

            // Set default status if StatusTextBox is empty or contains the placeholder
            string status = string.IsNullOrWhiteSpace(StatusTextBox.Text) || StatusTextBox.Text == "Enter Status"
                            ? "Cancelled"
                            : StatusTextBox.Text;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO PurchaseOrders (SupplierID, OrderDate, Status, TotalAmount) " +
                                   "VALUES (@SupplierID, @OrderDate, @Status, @TotalAmount)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierID", supplierID);
                        command.Parameters.AddWithValue("@OrderDate", DateTime.Now);
                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@TotalAmount", totalAmount);

                        command.ExecuteNonQuery();
                    }
                }

                // Log the action
                LogAudit(currentUserId, "Add", "PurchaseOrders", $"Added Order with Supplier ID: {supplierID}");
                StatusTextBlock.Text = "Order added successfully.";

                // Clear the input fields
                InitializePlaceholders();

                // Reload the orders
                LoadOrders();
            }
            catch (SqlException ex)
            {
                StatusTextBlock.Text = "Error adding order: " + ex.Message;
            }
            catch (FormatException)
            {
                StatusTextBlock.Text = "Error: Invalid input format. Please ensure the inputs are valid.";
            }
        }

        private void UpdateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (OrdersDataGrid.SelectedItem is PurchaseOrder selectedOrder &&
                !string.IsNullOrWhiteSpace(OrderDetailsTextBox.Text) &&
                TotalAmountTextBox.Text != "Enter Total Amount")
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE PurchaseOrders SET SupplierID = @SupplierID, Status = @Status, TotalAmount = @TotalAmount WHERE PurchaseOrderID = @PurchaseOrderID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@SupplierID", selectedOrder.SupplierID);
                            command.Parameters.AddWithValue("@Status", StatusTextBox.Text != "Enter Status" ? StatusTextBox.Text : "Cancelled");
                            command.Parameters.AddWithValue("@TotalAmount", decimal.Parse(TotalAmountTextBox.Text != "Enter Total Amount" ? TotalAmountTextBox.Text : "100"));
                            command.Parameters.AddWithValue("@PurchaseOrderID", selectedOrder.PurchaseOrderID);

                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Update", "PurchaseOrders", $"Updated Order ID: {selectedOrder.PurchaseOrderID}");
                    StatusTextBlock.Text = "Order updated successfully.";
                    InitializePlaceholders();
                    LoadOrders();
                }
                catch (SqlException ex)
                {
                    StatusTextBlock.Text = "Error updating order: " + ex.Message;
                }
                catch (FormatException)
                {
                    StatusTextBlock.Text = "Invalid input format. Please ensure the inputs are valid.";
                }
            }
            else
            {
                StatusTextBlock.Text = "Select an order to update.";
            }
        }

        private void DeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (OrdersDataGrid.SelectedItem is PurchaseOrder selectedOrder)
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM PurchaseOrders WHERE PurchaseOrderID = @PurchaseOrderID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@PurchaseOrderID", selectedOrder.PurchaseOrderID);
                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Delete", "PurchaseOrders", $"Deleted Order ID: {selectedOrder.PurchaseOrderID}");
                    StatusTextBlock.Text = "Order deleted successfully.";
                    InitializePlaceholders();
                    LoadOrders();
                }
                catch (SqlException ex)
                {
                    StatusTextBlock.Text = "Error deleting order: " + ex.Message;
                }
            }
            else
            {
                StatusTextBlock.Text = "Select an order to delete.";
            }
        }

        private void OrdersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (OrdersDataGrid.SelectedItem is PurchaseOrder selectedOrder)
            {
                OrderIdTextBox.Text = selectedOrder.PurchaseOrderID.ToString();
                OrderDetailsTextBox.Text = selectedOrder.Status; // Replace with appropriate detail field if available
                TotalAmountTextBox.Text = selectedOrder.TotalAmount.ToString("C"); // Format as currency
                StatusTextBox.Text = selectedOrder.Status;
            }
        }

        private void OrderIdTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (OrderIdTextBox.Text == "Enter Order ID")
            {
                OrderIdTextBox.Clear();
            }
        }

        private void OrderDetailsTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (OrderDetailsTextBox.Text == "Enter Order Details")
            {
                OrderDetailsTextBox.Clear();
            }
        }

        private void TotalAmountTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TotalAmountTextBox.Text == "Enter Total Amount")
            {
                TotalAmountTextBox.Clear();
            }
        }

        private void StatusTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (StatusTextBox.Text == "Enter Status")
            {
                StatusTextBox.Clear();
            }
        }
    }

    public class PurchaseOrder
    {
        public int PurchaseOrderID { get; set; }
        public int SupplierID { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
