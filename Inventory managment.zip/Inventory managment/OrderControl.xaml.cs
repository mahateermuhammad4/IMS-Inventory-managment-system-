﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace InventoryApp
{
    public partial class OrderControl : UserControl
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";

        private int currentUserId = 1;

        public OrderControl(int userid)
        {
            InitializeComponent();
            LoadOrders();
            InitializePlaceholders();
            currentUserId = userid;
        }

        private void LogAudit(int userId, string action, string tableAffected, string description)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime, Description) VALUES (@UserID, @Action, @TableAffected, @ActionTime, @Description)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Action", action);
                        command.Parameters.AddWithValue("@TableAffected", tableAffected);
                        command.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", description);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void InitializePlaceholders()
        {
            SupplierIdTextBox.Text = "Enter Order ID";
            OrderDetailsTextBox.Text = "Enter Order Details";
            TotalAmountTextBox.Text = "Enter Total Amount";
            StatusTextBox.Text = "Enter Status";
        }

        private void LoadOrders()
        {
            var orders = new List<PurchaseOrder>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM PurchaseOrders";
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var order = new PurchaseOrder
                            {
                                PurchaseOrderID = reader.GetInt32(0),
                                SupplierID = reader.GetInt32(1),
                                OrderDate = reader.GetDateTime(2),
                                Status = reader.GetString(3),
                                TotalAmount = reader.GetDecimal(4)
                            };
                            orders.Add(order);
                        }
                    }
                }

                OrdersDataGrid.ItemsSource = orders;
            }
            catch (SqlException ex)
            {
                StatusTextBlock.Text = "Error loading orders: " + ex.Message;
            }
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(SupplierIdTextBox.Text) || !int.TryParse(SupplierIdTextBox.Text, out int supplierID))
            {
                StatusTextBlock.Text = "Error: Invalid Supplier ID. Please enter a valid number.";
                return;
            }

           
            if (string.IsNullOrWhiteSpace(TotalAmountTextBox.Text) || !decimal.TryParse(TotalAmountTextBox.Text, out decimal totalAmount))
            {
                StatusTextBlock.Text = "Error: Invalid Total Amount. Please enter a valid number.";
                return;
            }

            // Set default status if StatusTextBox is empty or contains the placeholder
            string status = string.IsNullOrWhiteSpace(StatusTextBox.Text) || StatusTextBox.Text == "Enter Status"
                            ? "Cancelled"
                            : StatusTextBox.Text;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO PurchaseOrders (SupplierID, OrderDate, Status, TotalAmount) " +
                                   "VALUES (@SupplierID, @OrderDate, @Status, @TotalAmount)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierID", supplierID);
                        command.Parameters.AddWithValue("@OrderDate", DateTime.Now);
                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@TotalAmount", totalAmount);

                        command.ExecuteNonQuery();
                    }
                }

                
                LogAudit(currentUserId, "Add", "PurchaseOrders", $"Added Order with Supplier ID: {supplierID}");
                StatusTextBlock.Text = "Order added successfully.";

                
                InitializePlaceholders();

              
                LoadOrders();
            }
            catch (SqlException ex)
            {
                StatusTextBlock.Text = "Error adding order: " + ex.Message;
            }
            catch (FormatException)
            {
                StatusTextBlock.Text = "Error: Invalid input format. Please ensure the inputs are valid.";
            }
        }

        private void UpdateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (OrdersDataGrid.SelectedItem is PurchaseOrder selectedOrder)
            {
                string newStatus = StatusTextBox.Text;
                int newSupplierId; // Assume you have a ComboBox or similar for SupplierID

                // Validate the new status
                if (string.IsNullOrWhiteSpace(newStatus) || !IsValidStatus(newStatus))
                {
                    StatusTextBlock.Text = "Please select a valid status.";
                    return;
                }

                // If applicable, validate and parse the SupplierID
                if (!int.TryParse(SupplierIdTextBox.Text, out newSupplierId))
                {
                    StatusTextBlock.Text = "Invalid Supplier ID.";
                    return;
                }

                // Update the purchase order with the new values
                UpdatePurchaseOrderStatus(selectedOrder.PurchaseOrderID, newStatus, newSupplierId);
            }
            else
            {
                StatusTextBlock.Text = "Select a purchase order to update.";
            }
        }


        private void UpdatePurchaseOrderStatus(int purchaseOrderId, string newStatus, int newSupplierId)
        {
            if (string.IsNullOrEmpty(newStatus) || !IsValidStatus(newStatus))
            {
                StatusTextBlock.Text = "Invalid status.";
                return;
            }

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    if (newStatus.Equals("Cancelled", StringComparison.OrdinalIgnoreCase))
                    {
                        string detailsQuery = "SELECT ProductID, Quantity FROM PurchaseOrderDetails WHERE PurchaseOrderID = @PurchaseOrderID";
                        var details = new List<(int ProductID, int Quantity)>();

                        using (var detailsCommand = new SqlCommand(detailsQuery, connection))
                        {
                            detailsCommand.Parameters.AddWithValue("@PurchaseOrderID", purchaseOrderId);
                            using (var reader = detailsCommand.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    int productId = Convert.ToInt32(reader["ProductID"]);
                                    int quantity = Convert.ToInt32(reader["Quantity"]);
                                    details.Add((productId, quantity));
                                }
                            }
                        }

                        foreach (var detail in details)
                        {
                            string updateProductQuery = "UPDATE Products SET Quantity = Quantity + @Quantity WHERE ProductID = @ProductID";
                            using (var updateProductCommand = new SqlCommand(updateProductQuery, connection))
                            {
                                updateProductCommand.Parameters.AddWithValue("@Quantity", detail.Quantity);
                                updateProductCommand.Parameters.AddWithValue("@ProductID", detail.ProductID);
                                updateProductCommand.ExecuteNonQuery();
                            }
                        }

                        string deleteDetailsQuery = "DELETE FROM PurchaseOrderDetails WHERE PurchaseOrderID = @PurchaseOrderID";
                        using (var deleteDetailsCommand = new SqlCommand(deleteDetailsQuery, connection))
                        {
                            deleteDetailsCommand.Parameters.AddWithValue("@PurchaseOrderID", purchaseOrderId);
                            deleteDetailsCommand.ExecuteNonQuery();
                        }
                    }
                    else if (newStatus.Equals("Pending", StringComparison.OrdinalIgnoreCase) &&
                             IsOrderCancelled(purchaseOrderId))
                    {
                        StatusTextBlock.Text = "This order is cancelled and its status cannot be changed.";
                        return;
                    }

                    // Update the status and SupplierID of the Purchase Order
                    string updateOrderQuery = "UPDATE PurchaseOrders SET Status = @NewStatus WHERE PurchaseOrderID = @PurchaseOrderID";
                    using (var updateOrderCommand = new SqlCommand(updateOrderQuery, connection))
                    {
                        updateOrderCommand.Parameters.AddWithValue("@NewStatus", newStatus);
                      
                        updateOrderCommand.Parameters.AddWithValue("@PurchaseOrderID", purchaseOrderId);
                        updateOrderCommand.ExecuteNonQuery();
                    }
                }

                LogAudit(currentUserId, "Update", "PurchaseOrders", $"Updated Purchase Order ID: {purchaseOrderId} to status: {newStatus}");
                StatusTextBlock.Text = "Purchase order updated successfully.";
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Error updating purchase order: {ex.Message}";
            }
            LoadOrders();
        }

        private bool IsValidStatus(string status)
        {
            var validStatuses = new[] { "Pending", "Completed", "Cancelled" };
            return validStatuses.Contains(status);
        }

        private bool IsOrderCancelled(int purchaseOrderId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Status FROM PurchaseOrders WHERE PurchaseOrderID = @PurchaseOrderID";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PurchaseOrderID", purchaseOrderId);
                    var status = command.ExecuteScalar()?.ToString();
                    return status == "Cancelled";
                }
            }
        }



        private void DeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (OrdersDataGrid.SelectedItem is PurchaseOrder selectedOrder)
            {
                try
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM PurchaseOrders WHERE PurchaseOrderID = @PurchaseOrderID";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@PurchaseOrderID", selectedOrder.PurchaseOrderID);
                            command.ExecuteNonQuery();
                        }
                    }

                    LogAudit(currentUserId, "Delete", "PurchaseOrders", $"Deleted Order ID: {selectedOrder.PurchaseOrderID}");
                    StatusTextBlock.Text = "Order deleted successfully.";
                    InitializePlaceholders();
                    LoadOrders();
                }
                catch (SqlException ex)
                {
                    StatusTextBlock.Text = "Error deleting order: " + ex.Message;
                }
            }
            else
            {
                StatusTextBlock.Text = "Select an order to delete.";
            }
        }

        private void OrdersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (OrdersDataGrid.SelectedItem is PurchaseOrder selectedOrder)
            {
                SupplierIdTextBox.Text = selectedOrder.PurchaseOrderID.ToString();
                OrderDetailsTextBox.Text = selectedOrder.Status; 
                TotalAmountTextBox.Text = selectedOrder.TotalAmount.ToString("C"); 
                StatusTextBox.Text = selectedOrder.Status;
            }
        }

        private void OrderIdTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (SupplierIdTextBox.Text == "Enter Order ID")
            {
                SupplierIdTextBox.Clear();
            }
        }

        private void OrderDetailsTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (OrderDetailsTextBox.Text == "Enter Order Details")
            {
                OrderDetailsTextBox.Clear();
            }
        }

        private void TotalAmountTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TotalAmountTextBox.Text == "Enter Total Amount")
            {
                TotalAmountTextBox.Clear();
            }
        }

        private void StatusTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (StatusTextBox.Text == "Enter Status")
            {
                StatusTextBox.Clear();
            }
        }
    }

    public class PurchaseOrder
    {
        public int PurchaseOrderID { get; set; }
        public int SupplierID { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
