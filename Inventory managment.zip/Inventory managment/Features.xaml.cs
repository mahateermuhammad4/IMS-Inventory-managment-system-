﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace InventoryApp
{
    public partial class Features : Window
    {
        private readonly string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";
        private string userRole;

        public Features(string role)
        {
            InitializeComponent();
            userRole = role; 
            HideAllPanels(); 
            ConfigureAccess(); 
        }

        private void HideAllPanels()
        {
            DataGridDisplay.Visibility = Visibility.Collapsed;
            ManageStockPanel.Visibility = Visibility.Collapsed;
        }

        private void ConfigureAccess()
        {
           
            if (userRole == "Admin")
            {
                
                ManageStockButton.Visibility = Visibility.Visible;
                ViewProductsButton.Visibility = Visibility.Visible;
                ViewStockMovementsButton.Visibility = Visibility.Visible;
                ViewSuppliersButton.Visibility = Visibility.Visible;
                ViewSalesOrdersButton.Visibility = Visibility.Visible;
                ViewPurchaseOrdersButton.Visibility = Visibility.Visible;
                AuditLogsButton.Visibility = Visibility.Visible; 
            }
            else if (userRole == "Manager")
            {
               
                ManageStockButton.Visibility = Visibility.Visible;
                ViewProductsButton.Visibility = Visibility.Visible;
                ViewStockMovementsButton.Visibility = Visibility.Visible;
                ViewSuppliersButton.Visibility = Visibility.Visible;
                ViewSalesOrdersButton.Visibility = Visibility.Visible;
                ViewPurchaseOrdersButton.Visibility = Visibility.Visible;
                AuditLogsButton.Visibility = Visibility.Collapsed; 
            }
            else if (userRole == "Staff")
            {
               
                ManageStockButton.Visibility = Visibility.Collapsed; 
                ViewProductsButton.Visibility = Visibility.Visible;
                ViewStockMovementsButton.Visibility = Visibility.Visible;
                ViewSuppliersButton.Visibility = Visibility.Visible;
                ViewSalesOrdersButton.Visibility = Visibility.Visible;
                ViewPurchaseOrdersButton.Visibility = Visibility.Visible;
                AuditLogsButton.Visibility = Visibility.Collapsed; 
            }
            else
            {
                // Handle unknown roles
                MessageBox.Show("Unknown user role.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                this.Close(); 
            }
        }


        private void ViewProducts_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM Products";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ManageStock_Click(object sender, RoutedEventArgs e)
        {
            if (userRole == "Admin" || userRole == "Manager")
            {
                HideAllPanels();
                ManageStockPanel.Visibility = Visibility.Visible; 
            }
            else
            {
                MessageBox.Show("You do not have permission to manage stock.", "Access Denied", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ViewStockMovements_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM StockMovements";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewSuppliers_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM Suppliers";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewSalesOrders_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM SalesOrders";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewPurchaseOrders_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM PurchaseOrders";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewAuditLogs_Click(object sender, RoutedEventArgs e)
        {
            if (userRole == "Admin")
            {
                HideAllPanels();
                string query = "SELECT * FROM AuditLogs";
                LoadData(query);
                DataGridDisplay.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("You do not have permission to view audit logs.", "Access Denied", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void AddStockButton_Click(object sender, RoutedEventArgs e)
        {
            string productId = ProductIDInput.Text;
            string movementType = (MovementTypeInput.SelectedItem as ComboBoxItem)?.Content.ToString();
            string quantityText = QuantityInput.Text;
            string description = DescriptionInput.Text;

            if (string.IsNullOrWhiteSpace(productId) || string.IsNullOrWhiteSpace(movementType) || string.IsNullOrWhiteSpace(quantityText))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(quantityText, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Quantity must be a positive number.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Begin transaction
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Validate for "OUT" movement type to ensure no negative quantities
                            if (movementType == "OUT")
                            {
                                string checkQuantityQuery = "SELECT Quantity FROM Products WHERE ProductID = @ProductID";
                                using (SqlCommand checkCommand = new SqlCommand(checkQuantityQuery, connection, transaction))
                                {
                                    checkCommand.Parameters.AddWithValue("@ProductID", productId);
                                    object result = checkCommand.ExecuteScalar();
                                    if (result == null)
                                    {
                                        MessageBox.Show("Product not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                                        transaction.Rollback();
                                        return;
                                    }

                                    int currentQuantity = Convert.ToInt32(result);
                                    if (currentQuantity < quantity)
                                    {
                                        MessageBox.Show("Insufficient stock to perform this operation.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                                        transaction.Rollback();
                                        return;
                                    }
                                }
                            }

                            // Insert into StockMovements
                            string insertQuery = "INSERT INTO StockMovements (ProductID, MovementType, Quantity, Description) VALUES (@ProductID, @MovementType, @Quantity, @Description)";
                            using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection, transaction))
                            {
                                insertCommand.Parameters.AddWithValue("@ProductID", productId);
                                insertCommand.Parameters.AddWithValue("@MovementType", movementType);
                                insertCommand.Parameters.AddWithValue("@Quantity", quantity);
                                insertCommand.Parameters.AddWithValue("@Description", description);
                                insertCommand.ExecuteNonQuery();
                            }

                            // Update Products table based on movement type
                            string updateQuery = movementType switch
                            {
                                "IN" => "UPDATE Products SET Quantity = Quantity + @Quantity, UpdatedAt = GETDATE() WHERE ProductID = @ProductID",
                                "OUT" => "UPDATE Products SET Quantity = Quantity - @Quantity, UpdatedAt = GETDATE() WHERE ProductID = @ProductID",
                                "ADJUSTMENT" => "UPDATE Products SET Quantity = @Quantity, UpdatedAt = GETDATE() WHERE ProductID = @ProductID",
                                _ => throw new InvalidOperationException("Invalid movement type.")
                            };

                            using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection, transaction))
                            {
                                updateCommand.Parameters.AddWithValue("@ProductID", productId);
                                updateCommand.Parameters.AddWithValue("@Quantity", movementType == "ADJUSTMENT" ? quantity : quantity);
                                int rowsAffected = updateCommand.ExecuteNonQuery();

                                
                                if (rowsAffected == 0)
                                {
                                    MessageBox.Show("Failed to update product quantity. Please check the ProductID.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                                    transaction.Rollback();
                                    return;
                                }
                            }

                          
                            transaction.Commit();

                            MessageBox.Show("Stock movement and product quantity updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                            
                            ViewStockMovements_Click(sender, e);
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show($"Transaction error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }



        private void LoadData(string query)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridDisplay.ItemsSource = dataTable.DefaultView; 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
