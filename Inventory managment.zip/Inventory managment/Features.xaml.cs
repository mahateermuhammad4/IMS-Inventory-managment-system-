﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace InventoryApp
{
    public partial class Features : Window
    {
        private readonly string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True;Trust Server Certificate=True";
        private string userRole;

        public Features(string role)
        {
            InitializeComponent();
            userRole = role; // Store the user role
            HideAllPanels(); // Initially hide all panels
            ConfigureAccess(); // Configure access based on user role
        }

        private void HideAllPanels()
        {
            DataGridDisplay.Visibility = Visibility.Collapsed; // Hide DataGrid by default
            ManageStockPanel.Visibility = Visibility.Collapsed; // Hide Manage Stock panel by default
        }

        private void ConfigureAccess()
        {
            // Show or hide features based on the user role
            if (userRole == "Admin")
            {
                // Admin can view everything
                ManageStockButton.Visibility = Visibility.Visible;
                ViewProductsButton.Visibility = Visibility.Visible;
                ViewStockMovementsButton.Visibility = Visibility.Visible;
                ViewSuppliersButton.Visibility = Visibility.Visible;
                ViewSalesOrdersButton.Visibility = Visibility.Visible;
                ViewPurchaseOrdersButton.Visibility = Visibility.Visible;
                AuditLogsButton.Visibility = Visibility.Visible; // Show Audit Logs for Admin
            }
            else if (userRole == "Manager")
            {
                // Manager can view all except Audit Logs
                ManageStockButton.Visibility = Visibility.Visible;
                ViewProductsButton.Visibility = Visibility.Visible;
                ViewStockMovementsButton.Visibility = Visibility.Visible;
                ViewSuppliersButton.Visibility = Visibility.Visible;
                ViewSalesOrdersButton.Visibility = Visibility.Visible;
                ViewPurchaseOrdersButton.Visibility = Visibility.Visible;
                AuditLogsButton.Visibility = Visibility.Collapsed; // Hide Audit Logs
            }
            else if (userRole == "Staff")
            {
                // Staff can view only basic features
                ManageStockButton.Visibility = Visibility.Collapsed; // Hide Manage Stock
                ViewProductsButton.Visibility = Visibility.Visible;
                ViewStockMovementsButton.Visibility = Visibility.Visible;
                ViewSuppliersButton.Visibility = Visibility.Visible;
                ViewSalesOrdersButton.Visibility = Visibility.Visible;
                ViewPurchaseOrdersButton.Visibility = Visibility.Visible;
                AuditLogsButton.Visibility = Visibility.Collapsed; // Hide Audit Logs
            }
            else
            {
                // Handle unknown roles
                MessageBox.Show("Unknown user role.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                this.Close(); // Optionally close the window if the role is unknown
            }
        }


        private void ViewProducts_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM Products";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ManageStock_Click(object sender, RoutedEventArgs e)
        {
            if (userRole == "Admin" || userRole == "Manager")
            {
                HideAllPanels();
                ManageStockPanel.Visibility = Visibility.Visible; // Show the Manage Stock panel
            }
            else
            {
                MessageBox.Show("You do not have permission to manage stock.", "Access Denied", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ViewStockMovements_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM StockMovements";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewSuppliers_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM Suppliers";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewSalesOrders_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM SalesOrders";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewPurchaseOrders_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            string query = "SELECT * FROM PurchaseOrders";
            LoadData(query);
            DataGridDisplay.Visibility = Visibility.Visible;
        }

        private void ViewAuditLogs_Click(object sender, RoutedEventArgs e)
        {
            if (userRole == "Admin")
            {
                HideAllPanels();
                string query = "SELECT * FROM AuditLogs";
                LoadData(query);
                DataGridDisplay.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("You do not have permission to view audit logs.", "Access Denied", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void AddStockButton_Click(object sender, RoutedEventArgs e)
        {
            string productId = ProductIDInput.Text;
            string movementType = (MovementTypeInput.SelectedItem as ComboBoxItem)?.Content.ToString();
            string quantityText = QuantityInput.Text;
            string description = DescriptionInput.Text;

            if (string.IsNullOrWhiteSpace(productId) || string.IsNullOrWhiteSpace(movementType) || string.IsNullOrWhiteSpace(quantityText))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(quantityText, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Quantity must be a positive number.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                string query = "INSERT INTO StockMovements (ProductID, MovementType, Quantity, Description) VALUES (@ProductID, @MovementType, @Quantity, @Description)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ProductID", productId);
                    command.Parameters.AddWithValue("@MovementType", movementType);
                    command.Parameters.AddWithValue("@Quantity", quantity);
                    command.Parameters.AddWithValue("@Description", description);
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Stock added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                // Optionally refresh the stock movements after adding
                ViewStockMovements_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadData(string query)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridDisplay.ItemsSource = dataTable.DefaultView; // Bind data to DataGrid
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
